import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [color1, setColor1] = useState('#00ff00');
  const [color2, setColor2] = useState('#00ff00');
  const [background, setBackground] = useState('');

  const handleColorChange = (e) => {
    const newColor = e.target.value;
    if (e.target.name === 'color1') {
      setColor1(newColor);
    } else if (e.target.name === 'color2') {
      setColor2(newColor);
    }
    setBackground(`linear-gradient(to right, ${color1}, ${color2})`);
  };

  return (
    <div className="boxContainer">
      <div className="box" style={{ background }}>
        <h1>Background Generator</h1>
        <div className="colorPickers">
          <label htmlFor="color1">Color 1:</label>
          <input
            type="color"
            name="color1"
            value={color1}
            onChange={handleColorChange}
            className="color1"
          />
          <label htmlFor="color2">Color 2:</label>
          <input
            type="color"
            name="color2"
            value={color2}
            onChange={handleColorChange}
            className="color2"
          />
        </div>
        <h2>Current Background</h2>
        <h3>{`Color 1: ${color1}, Color 2: ${color2}`}</h3>
      </div>
    </div>
  );
};

export default App;
