let color1 = document.getElementById("colorPicker1");
let color2 = document.getElementById("colorPicker2");
let css = document.getElementById("gradient");
let currentColor = document.getElementById("currentColor");

function gradientChange() {
    let hexColor1 = color1.value;
    let hexColor2 = color2.value;
    css.style.background = `linear-gradient(to right, ${hexColor1}, ${hexColor2})`;
    currentColor.textContent = `Color 1: ${hexColor1}, Color 2: ${hexColor2}`;
}

color1.addEventListener("input", gradientChange);
color2.addEventListener("input", gradientChange);
