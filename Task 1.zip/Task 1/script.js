function startCountdown() {
    const userDateInput = document.getElementById("countdownDate").value;

    if (!userDateInput) {
        alert("Please enter a valid date and time.");
        return;
    }

    try {
        const countdownDate = new Date(userDateInput).getTime();
        const now = new Date().getTime();

        if (countdownDate <= now) {
            alert("Please enter a date and time in the future.");
            return;
        }

        const countdownItems = document.querySelectorAll(".countdown-item");
        const countdownMessage = document.querySelector(".countdown-message");

        document.getElementById("inputContainer").style.display = "none";
        const countdownItemContainer = document.querySelector(".countdown-item-container");
        countdownItemContainer.style.display = "flex";

        const countdownInterval = setInterval(function () {
            const currentNow = new Date().getTime();
            const distance = countdownDate - currentNow;

            if (distance < 0) {
                clearInterval(countdownInterval);
                countdownItems.forEach(item => (item.innerText = "0"));
                countdownMessage.innerText = "Countdown Ended";
            } else {
                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                countdownItems[0].innerText = days + "d";
                countdownItems[1].innerText = hours + "h";
                countdownItems[2].innerText = minutes + "m";
                countdownItems[3].innerText = seconds + "s";
            }
        }, 1000);
    } catch (error) {
        alert("Invalid date format. Please try again.");
    }
}
